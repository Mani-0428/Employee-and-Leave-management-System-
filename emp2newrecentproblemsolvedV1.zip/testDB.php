<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Employee Tracker — Platoon Title Services</title>
  <link rel="stylesheet" href="style.v39.css"/>
  <script src="app.v39.js" defer></script>
  <script>
    // ✅ Redirect to login if not authenticated
    document.addEventListener("DOMContentLoaded", () => {
      if (localStorage.getItem("isLoggedIn") !== "true") {
        window.location.href = "login.html";
      }
    });
  </script>
</head>
<body>
  <!-- Main Screen -->
  <section id="main-screen" class="screen active">
    <header class="topbar">
      <div class="brand">
        <svg class="logo" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 160 160" aria-label="Platoon Title Services">
          <defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#14b8a6"/><stop offset="100%" stop-color="#0ea5a4"/></linearGradient></defs>
          <rect x="10" y="10" width="140" height="140" rx="28" fill="url(#g)"/>
          <g fill="#ffffff" font-family="Inter, ui-sans-serif, system-ui" font-weight="800">
            <text x="32" y="86" font-size="64">PT</text>
            <text x="32" y="126" font-size="52">S</text>
          </g>
          <title>Platoon Title Services</title>
        </svg>
        <div>
          <div class="title">Platoon Title Services</div>
          <div class="subtitle">Employee Tracker</div>
        </div>
      </div>
      <div class="right">
        <button id="btn-logout" class="btn danger">Logout</button>
      </div>
    </header>

    <main class="container">
      <!-- Toolbar -->
      <div class="actions-bar">
        <button id="btn-add" class="btn">Add Employee</button>
        <button id="btn-delete-selected" class="btn danger">Delete Selected</button>
        <span id="selected-count" class="badge">0</span>
        <button id="btn-bulk-import" class="btn">Bulk Import</button>
        <button id="btn-export" class="btn">Export JSON</button>
        <button id="btn-export-csv" class="btn">Export CSV</button>
        <label class="file-btn">
          <input type="file" id="import-file" accept=".json" hidden>
          <span class="btn">Import JSON</span>
        </label>
        <button id="btn-settings" class="btn">Settings</button>
        <input id="search" type="search" placeholder="Search name, ID, email, department, IFSC, PAN, Aadhar..." />
      </div>

      <!-- Queues -->
      <div id="queues" class="queues">
        <button class="qbtn active" data-q="all">All Employees</button>
        <button class="qbtn" data-q="active">Active</button>
        <button class="qbtn" data-q="inactive">Inactive</button>
        <button class="qbtn" data-q="probation">Probation (≤ 3 mo)</button>
      </div>

      <!-- Employee Cards (mobile view) -->
      <div id="employee-list"></div>

      <!-- Employee Table (desktop view) -->
      <table id="emp-table">
        <thead>
          <tr>
            <th class="checkbox-col"><input type="checkbox" id="select-all" title="Select All"/></th>
            <th>#</th>
            <th>Name</th>
            <th>Employee ID</th>
            <th>Personal Email</th>
            <th>Official Email</th>
            <th>Department</th>
            <th>Joining Date</th>
            <th>DOB</th>
            <th>Salary (₹/mo)</th>
            <th>Exit Date</th>
            <th>Tenure (months)</th>
            <th>Status</th>
            <th>Blood Group</th>
            <th>Personal Phone</th>
            <th>Emergency Contact</th>
            <th>Account #</th>
            <th>IFSC</th>
            <th>PAN</th>
            <th>Aadhar</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody id="employee-table-body"></tbody>
      </table>
    </main>
  </section>


    <!-- (Keep your modal code here — same as before) -->
      <!-- Add/Edit Modal -->
  <div id="modal" class="modal hidden">
    <div class="modal-card">
      <div class="modal-header">
        <h3 id="modal-title">Add Employee</h3>
        <button id="modal-close" class="icon-btn">✕</button>
      </div>
      <div class="modal-body">
        <div class="tabs">
          <button class="tab active" data-tab="edit">Edit</button>
          <button class="tab" data-tab="attendance">Attendance</button>
          <button class="tab" data-tab="payslip">Payslip</button>
          <button class="tab" data-tab="offer">Offer Letter</button>
        </div>

        <div id="tab-edit" class="tab-pane active">

       <form id="emp-form" class="form-panels">

  <!-- Identity -->
  <fieldset class="panel">
    <legend>Identity</legend>
    <div class="grid two">
      <label>Name
        <input type="text" name="name" id="modal-name" required>
        <input type="hidden" name="id" id="modal-recordId" required>
      </label>
      <label>Employee ID
        <input type="text" name="empId" id="modal-employee-id" required>
         <!-- <input type="text" name="empId" id="modal-employee-id" required> -->

      </label>
      <label>Department
        <input type="text" name="department" id="modal-department" placeholder="Operations, QA, HR, IT, Finance">
      </label>
      <label>Blood Group
        <input type="text" name="bloodGroup" id="modal-blood-group" placeholder="A+, B+, O-, …">
      </label>
    </div>
  </fieldset>

  <!-- Contacts -->
  <fieldset class="panel">
    <legend>Contacts</legend>
    <div class="grid two">
      <label>Personal Email
        <input type="email" name="personalEmail" id="modal-personal-email" placeholder="name@example.com">
      </label>
      <label>Official Email
        <input type="email" name="officialEmail" id="modal-official-email" placeholder="name@platoontitleservices.com">
      </label>
      <label>Personal Contact Number
        <input type="tel" name="personalPhone" id="modal-personal-contact" placeholder="+91-XXXXXXXXXX">
      </label>
      <label>Emergency Contact
        <input type="tel" name="emergencyContact" id="modal-emergency-contact" placeholder="+91-XXXXXXXXXX">
      </label>
    </div>
  </fieldset>

  <!-- Employment -->
  <fieldset class="panel">
    <legend>Employment</legend>
    <div class="grid two">
      <label>Joining Date
        <input type="date" name="joiningDate" id="modal-joining-date" required>
      </label>
      <label>Date of Birth
        <input type="date" name="dob" id="modal-dob">
      </label>
      <label>Salary (₹/mo)
        <input type="number" name="salary" id="modal-salary" value="0" step="0.01" min="0" placeholder="50000">
      </label>
      <label>Exit Date
        <input type="date" name="exitDate" id="modal-exit-date">
      </label>
      <label>Tenure (months)
        <input type="number" name="tenure" id="modal-tenure" step="1" min="0" placeholder="0">
      </label>
      <label>Status
        <!-- <input type="text" name="status" id="modal-status" placeholder="Active / Inactive / Probation"> -->
         <select name="status" id="modal-status" class="form-actions">
          <option value="Active">Active</option>
          <option value="Inactive">Inactive</option>
          <option value="Probation">Probation</option>
         </select>
      </label>
      <label style="display:flex;align-items:center;gap:8px">Apply weekend (WOT) allowance
        <input type="checkbox" name="wotAllowance" id="modal-wotAllowance">
      </label>
    </div>
  </fieldset>

  <!-- Banking -->
  <fieldset class="panel">
    <legend>Banking</legend>
    <div class="grid two">
      <label>Account #
        <input type="text" name="accountNumber" id="modal-accountNumber">
        <small class="hint">Company may use this for salary credit.</small>
      </label>
      <label>IFSC Code
        <input type="text" name="ifsc" id="modal-ifsc" placeholder="HDFC0001234">
        <small class="hint">Format: 4 letters + 0 + 6 alphanumerics</small>
      </label>
    </div>
  </fieldset>

  <!-- IDs -->
  <fieldset class="panel">
    <legend>IDs</legend>
    <div class="grid two">
      <label>PAN Number
        <input type="text" name="pan" id="modal-pan" placeholder="ABCDE1234F">
        <small class="hint">Format: 5 letters + 4 digits + 1 letter</small>
      </label>
      <label>Aadhar Number
        <input type="text" name="aadhar" id="modal-aadhar" placeholder="12-digit number">
      </label>
    </div>
  </fieldset>

  <!-- Form Actions -->
  <div class="form-actions">
    <button class="btn" type="button" id="btn-cancel">Cancel</button>
    <button class="btn primary" type="submit">Save</button>
  </div>

</form>

</div>

        <div id="tab-attendance" class="tab-pane">
          <div class="row gap">
            <label>Month
              <input type="month" id="att-month">
            </label>
            <span id="weekend-badge" class="badge">Weekend</span>
            <button id="btn-export-att-csv" class="btn">Export Month CSV (All Employees)</button>
            <div class="legend">
              <span class="chip chip-p">D</span> Day Present
              <span class="chip chip-n">N</span> Night Present
              <span class="chip chip-lp">LP</span> Loss of Pay
              <span class="chip chip-l">L</span> Leave
              <span class="chip chip-wo">WO</span> Week Off
              <span class="chip chip-wot">WOT</span> Weekend Present
            </div>
          </div>
          <div id="att-grid" class="att-grid"></div>
          <div id="att-summary" class="att-summary muted"></div>
        </div>

        <div id="tab-payslip" class="tab-pane">
          <div class="row gap">
            <label>Month
              <input type="month" id="pay-month">
            </label>
            <!-- <button id="btn-generate-payslip" class="btn">Generate Payslip</button> -->
            <button id="btn-print-payslip" class="btn">Print / Save PDF</button>
          </div>
          <div id="payslip-preview" class="payslip"></div>
        </div>

        <div id="tab-offer" class="tab-pane">
          <div class="row gap">
            <button id="btn-generate-offer" class="btn">Generate Offer Letter</button>
            <button id="btn-print-offer" class="btn">Print / Save PDF</button>
          </div>
          <div id="offer-preview" class="offer"></div>
        </div>
      </div>
    </div>
  </div>
  </div>

  <!-- 🔹 Settings Modal -->
  <div id="settings" class="modal hidden">
    <!-- (Keep your settings form code here) -->
     
  <!-- Settings Modal -->
  <div id="settings" class="modal hidden">
    <div class="modal-card">
      <div class="modal-header">
        <h3>Settings</h3>
        <button id="settings-close" class="icon-btn">✕</button>
      </div>
      <div class="modal-body">
        <form id="settings-form" class="grid">
          <label>Storage Folder Hint
            <input name="storageHint" placeholder="P:\Management\Tool\Employee Tracker">
          </label>
          <label>Username
            <input name="username" placeholder="admin">
          </label>
          <label>Password
            <input type="password" name="password" placeholder="admin">
          </label>
          <label>PF %
            <input type="number" name="pfPct" step="0.1" min="0" max="100" placeholder="12">
          </label>
          <label style="display:flex;align-items:center;gap:8px">Leave (L) is paid
            <input type="checkbox" name="leavePaid" checked>
          </label>
          <label>Night (weekday) allowance ₹
            <input type="number" name="nightAllowance" step="1" min="0" placeholder="100">
          </label>
          <label>Weekend (WOT) allowance ₹
            <input type="number" name="weekendAllowance" step="1" min="0" placeholder="1000">
          </label>
          <div class="right" style="grid-column:1/-1;margin-top:8px">
            <button class="btn primary" type="submit">Save Settings</button>
          </div>
        </form>
      </div>
    </div>
  </div>
  </div>

  <!-- 🔹 Bulk Import Modal -->
  <div id="bulk-import" class="modal hidden">
    <!-- (Keep your bulk import code here) -->
      <!-- Bulk Import Modal -->
  <div id="bulk-import" class="modal hidden">
    <div class="modal-card">
      <div class="modal-header">
        <h3>Bulk Import Employees</h3>
        <button id="bulk-close" class="icon-btn">✕</button>
      </div>
      <div class="modal-body">
        <div class="grid">
          <div style="grid-column:1/-1" class="muted">
            Import employees from CSV/JSON. You can pick <b>multiple files</b>, or pick a <b>folder</b> (Chrome/Edge) and we’ll import all <code>.csv</code> / <code>.json</code> inside it.
          </div>
          <div><button id="btn-download-template-csv" class="btn">Download CSV Template</button></div>
          <div><button id="btn-download-template-json" class="btn">Download JSON Template</button></div>
          <div style="grid-column:1/-1">
            <label class="file-btn">
              <input type="file" id="bulk-files" accept=".csv,.json" multiple hidden>
              <span class="btn">Import CSV/JSON File(s)</span>
            </label>
          </div>
          <div style="grid-column:1/-1">
            <input type="file" id="bulk-folder" webkitdirectory directory multiple hidden>
            <button id="btn-choose-folder" class="btn">Choose Folder…</button>
            <div class="tiny muted">Folder pick works best on Chrome/Edge. On Firefox, use “Import CSV/JSON File(s)”.</div>
          </div>
          <div style="grid-column:1/-1" class="muted">
            <b>CSV headers</b> (case-insensitive): name, empId, personalEmail, officialEmail, department, joiningDate, dob, salary, exitDate, bloodGroup, personalPhone, emergencyContact, accountNumber, ifsc, pan, aadhar, status, wotAllowance
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>

  <script>
    // ✅ Logout handler
    document.addEventListener("DOMContentLoaded", () => {
      const btnLogout = document.getElementById("btn-logout");
      if (btnLogout) {
        btnLogout.addEventListener("click", () => {
          localStorage.removeItem("isLoggedIn");
          window.location.href = "login.html";
        });
      }
    });
  </script>
</body>
</html>
